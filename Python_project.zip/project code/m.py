import pygame
from random import *
pygame.init()
white=(255,255,255)
black=(0,0,0)


gameDisplay=pygame.display.set_mode((100,100))
pygame.display.set_caption('maze runner')
clock=pygame.time.Clock()
crashed=False
x=12.5
y=12.5
l=0
visit=[]
all=[]
visit.append(1)
all.append(-1)
for i in range(1,15,1):
    visit.append(0)
def generate(x,y,z,c):
    if(z==c+1):#right movement
        pygame.draw.line(gameDisplay,black,(x+12.5,y-12.5),(x+12.5,y+12.5))
    elif(z==c-1):#left movement
        pygame.draw.line(gameDisplay,black,(x-12.5,y-12.5),(x-12.5,y+12.5))
        
    elif(z==c+4):#down movement
        pygame.draw.line(gameDisplay,black,(x-12.5,y+12.5),(x+12.5,y+12.5))
    elif(z==c-4):#up movement
        pygame.draw.line(gameDisplay,black,(x-12.5,y-12.5),(x+12.5,y-12.5))
def select():
    for i in range(0,15,1):
        if(visit[i]==1)
            for j in range(0,i,1):
                if(i!=all[j])
                    return(i)                   
def neighbour(x,y,l):
    c=select()
    if(visit[c]==1):
            if(c==0):
                nbs.append(c+1)
                nbs.append(c+4)
            elif(c==3):
                nbs.append(c-1)
                nbs.append(c+4)
            elif(c==12):
                nbs.append(c-4)
                nbs.append(c+1)
            elif(c==15):
                nbs.append(c-1)
                nbs.append(c-4)
            elif(c%4==0 and c!=0):
                nbs.append(c+1)
                nbs.append(c-4)
                nbs.append(c+4)
            elif((c+1)%4==0 and c!=15 ):
                nbs.append(c-1)
                nbs.append(c-4)
                nbs.append(c+4)
            elif(c>=1 and c<=2):
                nbs.append(c-1)
                nbs.append(c+1)
                nbs.append(c+4)
            elif(c>=13 and c<=14):
                nbs.append(c-1)
                nbs.append(c+1)
                nbs.append(c-4)
            else:
                nbs.append(c-4)
                nbs.append(c-1)
                nbs.append(c+1)
                nbs.append(c+4)
        all.insert(l,c)
        all.append(-1)
        l=l+1
        m=choice(nbs)
        generate(x,y,m,c)
        visit[m]=1
        nbs=[]
        neighbour(c,x,y)
for i in range(0,100,25):
    
    for j in range(0,100,25):
                    
            pygame.draw.line(gameDisplay,white,(i,j),(i,j+25))
for j in range(0,100,25):
    for i in range(0,100,25):
            pygame.draw.line(gameDisplay,white,(i,j),(i+25,j))
pygame.display.update()

neighbour(12.5,12.5,l)
                
while not crashed:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            crashed = True
            
        print(event)
    
    clock.tick(60)
pygame.quit
quit()