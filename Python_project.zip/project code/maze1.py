import pygame
from random import *
pygame.init()

white=(255,255,255)
black=(0,0,0)


gameDisplay=pygame.display.set_mode((400,400))
pygame.display.set_caption('maze runner')
clock=pygame.time.Clock()
crashed=False
w=0
u=0
cx=w+12.5
cy=u+12.5

walls=[]
nbs=[]
visit=[]
visit.append=1;
#for i in range(0,256,1):
    #walls.append(4)
for i in range(1,15,1):
    visit.append(0)
#for i in range(0,240,1):
    #hwalls.append(1)    
cnt=0  

def genrate(x,y,cnt):
    ct=cnt
    pcnt=cnt
    c=0
    c1=1
    #for i in range (1,10000):
    while(c1!=256):
        if(visit[c]==1):
            if(c==0):
                nbs.append(c+1)
                nbs.append(c+4)
            else if(c==3)
                nbs.append(c-1)
                nbs.append(c+4)
            else if(c==12)
                nbs.append(c-4)
                nbs.append(c+1)
            else if(c==15)
                nbs.append(c-1)
                nbs.append(c-4)
            else if(c%4==0 and c!=0):
                nbs.append(c+1)
                nbs.append(c-4)
                nbs.append(c+4)
            else if((c+1)%4==0 and c!=15 ):
                nbs.append(c-1)
                nbs.append(c-4)
                nbs.append(c+4)
            else if(c>=1 and c<=2):
                nbs.append(c-1)
                nbs.append(c+1)
                nbs.append(c+4)
            else if(c>=13 and c<=14):
                nbs.append(c-1)
                nbs.append(c+1)
                nbs.append(c-4)
            else:
                nbs.append(c-4)
                nbs.append(c-1)
                nbs.append(c+1)
                nbs.append(c+4)
        a=choice(nbs)
        
            
            
                
            
        
            
            
            
            pcnt=ct
            print("pcnt: ",pcnt)
            
            ct=ct+16
            print("ct :",ct)
            print("c :",c)
            v1=walls[ct]
            v2=walls[pcnt]
            #visit[ct]=0
            visit[pcnt]=0
            c=c+1
            if(ncx<400 and ncy<400 and ncx>0 and ncy>0 and v1>=4 and v2>=4):
                pygame.draw.line(gameDisplay,black,(x-12.5,y+12.5),(x+12.5,y+12.5))
                x=ncx
                y=ncy
               
                walls.insert(pcnt,v2-1)
                walls.insert(ct,v1-1)
        if((a==2 and ct%15!=0 and visit[ct]==1)or(a==2 and ct==0)):#right movement
            ncx=x+25
            ncy=y
           
            
            pcnt=ct
            print("pcnt: ",pcnt)
            ct=ct+1
            print("ct :",ct)
            print("c :",c)
            
            v1=walls[ct]
            v2=walls[pcnt]
            #visit[ct]=0
            visit[pcnt]=0
            c=c+1
            
            if(ncx<400 and ncy<400 and ncx>0 and ncy>0 and v1>=4 and v2>=4):
                pygame.draw.line(gameDisplay,black,(x+12.5,y-12.5),(x+12.5,y+12.5))
                x=ncx
                y=ncy
                walls.insert(pcnt,v2-1)
                walls.insert(ct,v1-1)
        if(a==3 and ct%16!=0 and visit[ct]==1):#left movement
            ncx=x-25
            ncy=y
            
            
            pcnt=ct
            print("pcnt: ",pcnt)
            ct=ct-1
            print("ct :",ct)
            print("c :",c)
            #vwall[pcnt]=0
            
            v1=walls[ct]
            v2=walls[pcnt]
            #visit[ct]=0
            visit[pcnt]=0
            c=c+1
            
            if(ncx<400 and ncy<400 and ncx>0 and ncy>0 and v1>=4 and v2>=4):
                pygame.draw.line(gameDisplay,black,(x-12.5,y-12.5),(x-12.5,y+12.5))
                x=ncx
                y=ncy
                walls.insert(pcnt,v2-1)
                walls.insert(ct,v1-1)
        if(a==4 and ct>15 and visit[ct]==1):#up movement
            ncx=x
            ncy=y-25
            
            
            pcnt=ct
            print("pcnt: ",pcnt)
            ct=ct-16
            print("ct :",ct)
            print("c :",c)
            
            v1=walls[ct]
            v2=walls[pcnt]
            #visit[ct]=0
            visit[pcnt]=0
            c=c+1
            
            
            if(ncx<400 and ncy<400 and ncx>0 and ncy>0 and v1>=4 and v2>=4):
                pygame.draw.line(gameDisplay,black,(x-12.5,y-12.5),(x+12.5,y-12.5))
                x=ncx
                y=ncy
                walls.insert(pcnt,v2-1)
                walls.insert(ct,v1-1)
                

#pygame.draw.rect(gameDisplay,white,(100,100,10,10))
for i in range(0,400,25):
    
    for j in range(0,400,25):
                    
            pygame.draw.line(gameDisplay,white,(i,j),(i,j+25))
for j in range(0,400,25):
    for i in range(0,400,25):
            pygame.draw.line(gameDisplay,white,(i,j),(i+25,j))
genrate(cx,cy,0)
pygame.display.update()                
l=0               
for i in range(0,16):
    for j in range(0,16):    
        print(walls[l],end=' ')
        l+=1
    print(end="")            
                
                
                
                
while not crashed:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            crashed = True
            
        print(event)
    
    clock.tick(60)
pygame.quit
quit()