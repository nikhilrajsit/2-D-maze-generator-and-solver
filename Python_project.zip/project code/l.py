visit=[]
print(visit[0])